﻿namespace ESignature.ServiceLayer.ESignCloud
{
    public class ESignCloudSetting
    {
        public string AgreementUUID { get; set; }
        public string PassCode { get; set; }
        public string RestUrl { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
        public string KeyStore { get; set; }
        public string KeyStorePassword { get; set; }
        public int MaxThreads { get; set; }
    }
}