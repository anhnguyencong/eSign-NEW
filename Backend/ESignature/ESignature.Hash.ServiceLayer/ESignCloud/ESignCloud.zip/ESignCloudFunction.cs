﻿using lib.rssp.sign;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;

namespace ESignature.ServiceLayer.ESignCloud
{
    public class ESignCloudFunction : SigningMethodSnyc
    {
        private readonly string AUTH_LOGIN = "auth/login";
        private readonly string CREDENTIALS_INFO = "credentials/info";
        private readonly string CREDENTIAL_AUTHORIZE = "credentials/authorize";
        private readonly string SIGNATURES_SIGNHASH = "signatures/signHash";
        private readonly string RestUrl;
        private readonly string RelyingParty = "GIC";
        private readonly string RelyingPartyUser;
        private readonly string RelyingPartyPassword;
        private readonly string RelyingPartySignature = "Uyv/jAMlI1V5DIiW/Bb4deSp+2b1yjWCpCskQcLlibvmHI9eU7JSRxV9XUv/FPN8AzQMCSrh7qeG6amp7HQFqonva3NY9EbOFFI/wJjNzfy0mT1eRe4A2PJsmYS6T9kDRmxcu9NWrAcLJLdBuFPg78Cq8ukfuGzHtyAPCXuIXi6sg0r59DtBUypOE8HZuf6KAfaf/Hj/xjfC1fDWGteEyIRt9Z/riW6+EPUeT+csiAftvHSAd+v+8H+ir1WJLKOjjmx2djFJ9FV+IHWHxQBkc3SQDzsooyJvTRSEu2RSaj7Yg9mAIfZSWOKNm0PpBIdOrQMkIYeeXjZeM80njEc0gw==";
        private readonly string RelyingPartyKeyStore;
        private readonly string RelyingPartyKeyStorePassword;
        private readonly string Profile = "rssp-119.432-v2.0";
        private readonly string Language = "VN";
        private readonly string AgreementUUID;
        private readonly string CredentialID;
        private readonly string PassCode;
        private string SAD;
        private string Bearer;

        public ESignCloudFunction(IOptions<ESignCloudSetting> options)
        {
            RestUrl = options.Value.RestUrl;
            RelyingPartyUser = options.Value.Username;
            RelyingPartyPassword = options.Value.Password;
            RelyingPartyKeyStore = options.Value.KeyStore;
            RelyingPartyKeyStorePassword = options.Value.KeyStorePassword;
            AgreementUUID = options.Value.AgreementUUID;
        }

        public List<string> GetCert()
        {
            RsspResponse response = CredentialsInfo();
            List<string> certList = new List<string>();
            foreach (string base64Cert in response.cert.certificates)
            {
                certList.Add(base64Cert);
            }
            return certList;
        }

        public List<string> Sign(List<string> hashList)
        {
            CredentialsAuthorize(hashList, null);
            RsspResponse response = CredentialSignHash(hashList);
            List<string> sigList = new List<string>(response.signatures);
            return sigList;
        }

        public RsspResponse CredentialsInfo()
        {
            Console.WriteLine("____________credentials/Info____________");
            RsspRequest request = new RsspRequest(this.RestUrl, this.RelyingPartyUser, this.RelyingPartyPassword,
                    this.RelyingPartySignature, this.RelyingPartyKeyStore, this.RelyingPartyKeyStorePassword,
                    this.Profile);
            request.lang = this.Language;
            request.agreementUUID = this.AgreementUUID;
            request.bearer = Bearer;
            // Khi ky phai truyen chain
            request.certificates = "chain";
            //request.certificates = "single";
            request.certInfo = false;
            request.authInfo = true;
            request.credentialID = this.CredentialID;

            string jsonReq = JsonConvert.SerializeObject(
            request, new JsonSerializerSettings { NullValueHandling = NullValueHandling.Ignore });

            string jsonResp = request.SendPost(RestUrl + CREDENTIALS_INFO, jsonReq, Function.DEFAULT);

            Console.WriteLine(jsonResp);
            JsonSerializerSettings jsonSerializerSettings = new JsonSerializerSettings
            {
                TypeNameHandling = TypeNameHandling.Objects,
                TypeNameAssemblyFormatHandling = TypeNameAssemblyFormatHandling.Simple,
                Converters = new[] { new ByteArrayConverter() }
            };
            RsspResponse signCloudResp = JsonConvert.DeserializeObject<RsspResponse>(jsonResp, jsonSerializerSettings);
            if (signCloudResp.error == 3005 || signCloudResp.error == 3006)
            {
                Bearer = null;
                AuthLogin();
                return CredentialsInfo();
            }
            return signCloudResp;
        }

        private void AuthLogin()
        {
            if (Bearer != null)
            {
                return;
            }
            RsspRequest request = new RsspRequest(this.RestUrl, this.RelyingPartyUser, this.RelyingPartyPassword,
                    this.RelyingPartySignature, this.RelyingPartyKeyStore, this.RelyingPartyKeyStorePassword, this.Profile);
            request.rememberMe = false;
            request.relyingParty = this.RelyingParty;
            request.lang = this.Language;
            string jsonReq = JsonConvert.SerializeObject(
            request, new JsonSerializerSettings { NullValueHandling = NullValueHandling.Ignore });
            string jsonResp = request.SendPost(RestUrl + AUTH_LOGIN, jsonReq, Function.AUTH_LOGIN_SSL_ONLY);
            JsonSerializerSettings jsonSerializerSettings = new JsonSerializerSettings
            {
                TypeNameHandling = TypeNameHandling.Objects,
                TypeNameAssemblyFormatHandling = TypeNameAssemblyFormatHandling.Simple,
                Converters = new[] { new ByteArrayConverter() }
            };
            RsspResponse signCloudResp = JsonConvert.DeserializeObject<RsspResponse>(jsonResp, jsonSerializerSettings);

            Bearer = signCloudResp.accessToken;
        }

        public RsspResponse CredentialSignHash(List<String> hash)//, String string)
        {
            RsspRequest request = new RsspRequest(this.RestUrl, this.RelyingPartyUser, this.RelyingPartyPassword,
                    this.RelyingPartySignature, this.RelyingPartyKeyStore, this.RelyingPartyKeyStorePassword,
                    this.Profile);
            request.lang = this.Language;
            request.agreementUUID = this.AgreementUUID;
            request.bearer = Bearer;
            request.credentialID = this.CredentialID;
            request.SAD = this.SAD;
            request.documentDigests = new DocumentDigests();
            request.documentDigests.hashAlgorithmOID = "2.16.840.1.101.3.4.2.1";
            request.documentDigests.hashes = hash;
            request.signAlgo = "1.2.840.113549.1.1.1";
            string jsonReq = JsonConvert.SerializeObject(
            request, new JsonSerializerSettings { NullValueHandling = NullValueHandling.Ignore });

            string jsonResp = request.SendPost(RestUrl + SIGNATURES_SIGNHASH, jsonReq, Function.DEFAULT);
            JsonSerializerSettings jsonSerializerSettings = new JsonSerializerSettings
            {
                TypeNameHandling = TypeNameHandling.Objects,
                TypeNameAssemblyFormatHandling = TypeNameAssemblyFormatHandling.Simple,
                Converters = new[] { new ByteArrayConverter() }
            };
            RsspResponse signCloudResp = JsonConvert.DeserializeObject<RsspResponse>(jsonResp, jsonSerializerSettings);
            if (signCloudResp.error == 3005 || signCloudResp.error == 3006)
            {
                Bearer = null;
                AuthLogin();
                return CredentialSignHash(hash);
            }
            Console.WriteLine(jsonResp);
            return signCloudResp;
        }

        private void CredentialsAuthorize(List<string> hash, byte[] bytes)
        {
            RsspRequest request = new RsspRequest(this.RestUrl, this.RelyingPartyUser, this.RelyingPartyPassword,
                    this.RelyingPartySignature, this.RelyingPartyKeyStore, this.RelyingPartyKeyStorePassword,
                    this.Profile);
            request.lang = this.Language;
            request.agreementUUID = this.AgreementUUID;
            request.bearer = Bearer;
            request.credentialID = this.CredentialID;
            request.numSignatures = hash.Count();
            request.documentDigests = new DocumentDigests();
            request.documentDigests.hashAlgorithmOID = "2.16.840.1.101.3.4.2.1";
            Console.WriteLine("===> Selected Mode EXPLICIT/PIN <===");
            request.authorizeCode = this.PassCode;
            string jsonReq = JsonConvert.SerializeObject(
            request, new JsonSerializerSettings { NullValueHandling = NullValueHandling.Ignore });

            string jsonResp = request.SendPost(RestUrl + CREDENTIAL_AUTHORIZE, jsonReq, Function.DEFAULT);
            JsonSerializerSettings jsonSerializerSettings = new JsonSerializerSettings
            {
                TypeNameHandling = TypeNameHandling.Objects,
                TypeNameAssemblyFormatHandling = TypeNameAssemblyFormatHandling.Simple,
                Converters = new[] { new ByteArrayConverter() }
            };
            RsspResponse signCloudResp = JsonConvert.DeserializeObject<RsspResponse>(jsonResp, jsonSerializerSettings);

            this.SAD = signCloudResp.SAD;

            if (signCloudResp.error == 3005 || signCloudResp.error == 3006)
            {
                Bearer = null;
                AuthLogin();
                CredentialsAuthorize(hash, bytes);
            }
        }
    }
}